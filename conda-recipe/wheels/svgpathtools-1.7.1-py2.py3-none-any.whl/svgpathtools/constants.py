"""This submodule contains constants used throughout the project."""

FLOAT_EPSILON = 1e-12
